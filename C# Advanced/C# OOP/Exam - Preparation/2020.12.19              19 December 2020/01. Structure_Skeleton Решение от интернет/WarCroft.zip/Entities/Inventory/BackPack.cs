﻿
namespace WarCroft.Entities.Inventory
{
    public class BackPack : Bag
    {
        public BackPack()
            : base(100)
        {
        }
    }
}