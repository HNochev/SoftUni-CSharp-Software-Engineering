﻿using System;

namespace VetClinic
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Clinic clinic = new Clinic(20);

            Pet dog = new Pet("Elias", 5, "Tim");

            clinic.Add(dog);

            Console.WriteLine(clinic.Remove("Elias"));

        }
    }
}
