﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-QE96OKD\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
