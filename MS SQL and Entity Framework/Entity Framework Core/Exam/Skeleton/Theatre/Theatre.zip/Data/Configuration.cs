﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-QE96OKD\SQLEXPRESS;Database=Theatre;Trusted_Connection=True";
    }
}
