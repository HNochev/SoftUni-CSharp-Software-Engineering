﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList()
            { "Amy",
            "Bet",
            "Sharon",
            "Zed",
            "Ben",
            "Nat"
            };

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(list.RandomString());
            }

        }
    }
}
